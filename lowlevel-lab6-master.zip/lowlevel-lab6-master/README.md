[Использованная документация по BMP](https://docs.microsoft.com/ru-ru/windows/win32/gdi/bitmap-storage?redirectedfrom=MSDN)
